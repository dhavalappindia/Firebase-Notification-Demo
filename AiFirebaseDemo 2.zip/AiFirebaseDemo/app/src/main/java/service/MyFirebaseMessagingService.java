package service;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.RemoteViews;

import com.ai.aifirebasedemo.HomeActivity;
import com.ai.aifirebasedemo.R;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import utils.MyPreference;




public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "tag";
    Bitmap bitmap = null;
    MyPreference myPreference;

    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);

        Log.d(TAG, "FCM token: " + token);
        myPreference = new MyPreference(getApplicationContext());
        myPreference.setDeviceToken(token);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        Log.d(TAG, "From: ");

        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
        }

        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }

        String title = "", message = "", noti_type = "";


        if (remoteMessage.getData().get("image") != null)
            bitmap = getBitmapfromUrl(remoteMessage.getData().get("image"));

        if (remoteMessage.getData().get("title") != null)
            title = remoteMessage.getData().get("title");
        else
            title = getResources().getString(R.string.app_name);

        if (remoteMessage.getData().get("message") != null)
            message = remoteMessage.getData().get("message");


        if (remoteMessage.getData().get("noti_type") != null)
            noti_type = remoteMessage.getData().get("noti_type");
        Log.d(TAG, "notification type--" + noti_type);


        sendNotification(message, title, noti_type, bitmap);


    }

    public Bitmap getBitmapfromUrl(String imageUrl) {
        Log.d("Tag", imageUrl);
        try {
            URL url = new URL(imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            return bitmap;

        } catch (Exception e) {
            e.printStackTrace();
            return null;

        }
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    private void sendNotification(String messageBody, String title, String noti_type, Bitmap image) {
        Intent intent = new Intent(MyFirebaseMessagingService.this, HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("noti_type", noti_type);
        Log.d(TAG, "noti_tyoe--" + noti_type);


        PendingIntent pendingIntent = PendingIntent.getActivity(this, (int) System.currentTimeMillis() /* Request code */, intent,
                PendingIntent.FLAG_ONE_SHOT);


        int notifyID = 1;
        String CHANNEL_ID = "my_channel_01";
        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CharSequence name = getString(R.string.app_name);// The user-visible name of the channel.
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
            RemoteViews contentView = new RemoteViews
                    (getPackageName(), R.layout.design_notification);
            if (image != null)
                contentView.setImageViewBitmap(R.id.ivVideoThumb, image);
            contentView.setTextViewText(R.id.tvTitle, title);
            contentView.setTextViewText(R.id.tvDes, messageBody);

            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
                    .setContentTitle(title)
                    .setSubText("")
                    .setContentText(messageBody)
                    .setAutoCancel(true)
                    .setSound(defaultSoundUri)
                    .setCustomBigContentView(contentView)
                    .setChannelId(CHANNEL_ID)
                    .setContentIntent(pendingIntent);

//            notificationBuilder.setSmallIcon(R.drawable.ic_money_bag);

            notificationManager.createNotificationChannel(mChannel);

//            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

//            notificationManager.notify((int) System.currentTimeMillis() /* ID of notification */, notificationBuilder.build());
            notificationManager.notify(notifyID, notificationBuilder.build());

        } else {
            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
                    .setContentTitle(title)
                    .setSubText("")
                    .setContentText(messageBody)
                    .setStyle(new NotificationCompat.BigPictureStyle()
                            .bigPicture(image))
                    .setAutoCancel(true)
                    .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);

            notificationBuilder.setSmallIcon(R.mipmap.ic_launcher);

            notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

//            notificationManager.notify((int) System.currentTimeMillis() /* ID of notification */, notificationBuilder.build());
            notificationManager.notify(notifyID, notificationBuilder.build());

        }


//        int notifyID = 1;
//
//
//        NotificationManager notificationManager =
//                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
////        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
////            mNotificationManager.createNotificationChannel(mChannel);
////        }
//        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
//            Log.d(TAG, "if notification above lolipop");
//            CharSequence name = getString(R.string.common_google_play_services_notification_channel_name);// The user-visible name of the channel.
//            int importance = NotificationManager.IMPORTANCE_HIGH;
//            NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
//
//            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
//                    .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.logo))
//                    .setSubText("")
//
//                    .setContentTitle(title)
//                    .setSmallIcon(getNotificationIcon())
//                    .setColor(getNotificationColor())
//                    .setContentText(subject)
//                    .setPriority(Notification.PRIORITY_HIGH)
//                    .setChannelId(CHANNEL_ID)
//                    .setAutoCancel(true);
//            notificationBuilder.setSmallIcon(R.drawable.logo);
//
////            NotificationManager notificationManager =
////                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//            notificationManager.createNotificationChannel(mChannel);
//
////            notificationManager.notify((int) System.currentTimeMillis() /* ID of notification */, notificationBuilder.build());
//            notificationManager.notify(notifyID, notificationBuilder.build());
//
//        } else {
//            Log.d(TAG, "else lolipop");
//            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
//            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
//                    .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
//                    .setSubText("")
//
//                    .setContentTitle(title)
//                    .setSmallIcon(getNotificationIcon())
//                    .setColor(getNotificationColor())
//                    .setContentText(subject)
//                    .setPriority(Notification.PRIORITY_HIGH)
//                    .setAutoCancel(true);
////                    .setStyle(bigText);
//
//
//            notificationBuilder.setSmallIcon(R.drawable.logo);
//
//            notificationManager =
//                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//
////            notificationManager.notify((int) System.currentTimeMillis() /* ID of notification */, notificationBuilder.build());
//            notificationManager.notify(notifyID, notificationBuilder.build());
//        }

    }

}