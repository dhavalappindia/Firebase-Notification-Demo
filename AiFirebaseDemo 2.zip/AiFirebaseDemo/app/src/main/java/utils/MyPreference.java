package utils;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class MyPreference {


    SharedPreferences myPrefs;
    SharedPreferences.Editor prefEditor;
    Context context;

    @SuppressWarnings("static-access")
    public MyPreference(Context context) {
        this.context = context;
        myPrefs = context.getSharedPreferences("book_my_table", context.MODE_PRIVATE);
    }

    public void clearPrefs() {
        prefEditor = myPrefs.edit();
        prefEditor.clear();
        prefEditor.commit();
    }



    /*----------------------------------------user is login-----------------------------------------*/


    public void setIsLogin(boolean isLogin) {
        prefEditor = myPrefs.edit();
        prefEditor.putBoolean("isLogin", isLogin);
        prefEditor.commit();
    }

    public boolean getIsLogin() {
        return myPrefs.getBoolean("isLogin", false);
    }

/*----------------------------------------user is login-----------------------------------------*/


    // ---------------------------setDeviceToken------------------------------------------------

    public void setDeviceToken(String token) {
        prefEditor = myPrefs.edit();
        prefEditor.putString("deviceToken", token);
        prefEditor.commit();
    }


    public String getDeviceToken() {
        return myPrefs.getString("deviceToken", "");
    }


    /*-----------------------------is Rated App-------------------------------------------*/
    public void setISRatedApp(boolean isRatedApp) {
        prefEditor = myPrefs.edit();
        prefEditor.putBoolean("isRatedApp", isRatedApp);
        prefEditor.commit();
    }

    public boolean getISRatedApp() {
        return myPrefs.getBoolean("isRatedApp", true);
    }
    /*-----------------------------------------------------------------------------------*/


    /*----------------------------------------user id-----------------------------------------*/

    public void setUserId(String userId) {
        prefEditor = myPrefs.edit();
        prefEditor.putString("userId", userId);
        prefEditor.commit();

    }

    public String getuserId() {
        return myPrefs.getString("userId", "");
    }
    /*----------------------------------------user name-----------------------------------------*/

    public void setUserName(String userName) {
        prefEditor = myPrefs.edit();
        prefEditor.putString("userName", userName);
        prefEditor.commit();

    }

    public String getuserName() {
        return myPrefs.getString("userName", "");
    }

    /*----------------------------------------user email-----------------------------------------*/

    public void setUserEmail(String userEmail) {
        prefEditor = myPrefs.edit();
        prefEditor.putString("userEmail", userEmail);
        prefEditor.commit();

    }

    public String getuserEmail() {
        return myPrefs.getString("userEmail", "");
    }


    /*----------------------------------------user phone-----------------------------------------*/

    public void setUserPhone(String userPhone) {
        prefEditor = myPrefs.edit();
        prefEditor.putString("userPhone", userPhone);
        prefEditor.commit();

    }

    public String getuserPhone() {
        return myPrefs.getString("userPhone", "");
    }

    /*----------------------------------------user password-----------------------------------------*/

    public void setUserPassword(String userPassword) {
        prefEditor = myPrefs.edit();
        prefEditor.putString("userPassword", userPassword);
        prefEditor.commit();

    }

    public String getuserPassword() {
        return myPrefs.getString("userPassword", "");
    }
}