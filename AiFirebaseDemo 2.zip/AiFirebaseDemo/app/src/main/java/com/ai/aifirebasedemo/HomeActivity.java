package com.ai.aifirebasedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import utils.MyPreference;

public class HomeActivity extends AppCompatActivity {
    TextView tv_firebase_token;
    MyPreference myPreference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        tv_firebase_token = findViewById(R.id.tv_firebase_token);
        myPreference = new MyPreference(HomeActivity.this);



        Log.d("tag", "notification ---" + getIntent().hasExtra("noti_type"));
        displayFirebaseRegId();
    }

    private void displayFirebaseRegId() {
//        SharedPreferences pref = getApplicationContext().getSharedPreferences(Config.SHARED_PREF, 0);
//        String regId = pref.getString("regId", null);

        Log.d("tag", "Firebase reg id: " + myPreference.getDeviceToken());
        tv_firebase_token.setText(myPreference.getDeviceToken());
//        if (!TextUtils.isEmpty(regId))
//            txtRegId.setText("Firebase Reg Id: " + regId);
//        else
//            txtRegId.setText("Firebase Reg Id is not received yet!");
    }
}
